import random
def bin2hex(binary):
    return ''.join(hex(int(binary[i:i+4], 2))[2:] for i in range(0, len(binary), 4))
ifp = [
    40, 8, 48, 16, 56, 24, 64, 32, 
    39, 7, 47, 15, 55, 23, 63, 31, 
    38, 6, 46, 14, 54, 22, 62, 30, 
    37, 5, 45, 13, 53, 21, 61, 29, 
    36, 4, 44, 12, 52, 20, 60, 28, 
    35, 3, 43, 11, 51, 19, 59, 27, 
    34, 2, 42, 10, 50, 18, 58, 26, 
    33, 1, 41, 9, 49, 17, 57, 25 ]
d={
    '0':'d',
    '1':'e',
    '2':'f',
    '3':'g',
    '4':'h',
    '5':'i',
    '6':'j',
    '7':'k',
    '8':'l',
    '9':'m',
    'a':'n',
    'b':'o',
    'c':'p',
    'd':'q',
    'e':'r',
    'f':'s'
}
p=0
XOR={0x4008000004000000,0x0020000800000400}
f1=open("input1.txt","w")
f2=open("input2.txt","w")
f1.write("The_Triple_Hits\ncrypto123\n4\nread\n")
f2.write("The_Triple_Hits\ncrypto123\n4\nread\n")
while(p<500):
    x=random.randint(0x1000000000000000,0xffffffffffffffff)
    a=hex(x)
    b=hex((0x4008000004000000)^x)
    a=bin(int(a, 16))[2:].zfill(64)
    b=bin(int(b, 16))[2:].zfill(64)
    o1=""
    o2=""
    # print(a,b)
    for i in range(0,64):
        o1+=a[ifp[i]-1]
    for i in range(0,64):
        o2+=b[ifp[i]-1]
    o1=bin2hex(o1)
    o2=bin2hex(o2)
    # print(len(o1),len(o2))
    # print(o1,o2)
    out1=""
    for i in o1:
        out1+=d[i]
    out2=""
    for i in o2:
        out2+=d[i]
    f1.write(out1)
    f1.write("\n")
    f1.write('c\n')
    f2.write(out2)
    f2.write("\n")
    f2.write('c\n')
    p+=1
f1.write("back\nexit")
f2.write("back\nexit")
f1.close()
f2.close()
f1=open("input3.txt","w")
f2=open("input4.txt","w")
f1.write("The_Triple_Hits\ncrypto123\n4\nread\n")
f2.write("The_Triple_Hits\ncrypto123\n4\nread\n")
p=0
while(p<500):
    x=random.randint(0x1000000000000000,0xffffffffffffffff)
    a=hex(x)
    b=hex((0x0020000800000400)^x)
    a=bin(int(a, 16))[2:].zfill(64)
    b=bin(int(b, 16))[2:].zfill(64)
    o1=""
    o2=""
    for i in range(0,64):
        o1+=a[ifp[i]-1]
    for i in range(0,64):
        o2+=b[ifp[i]-1]
    o1=bin2hex(o1)
    o2=bin2hex(o2)
    out1=""
    for i in o1:
        out1+=d[i]
    out2=""
    for i in o2:
        out2+=d[i]
    f1.write(out1)
    f1.write("\n")
    f1.write('c\n')
    f2.write(out2)
    f2.write("\n")
    f2.write('c\n')
    p+=1
f1.write("back\nexit")
f2.write("back\nexit")