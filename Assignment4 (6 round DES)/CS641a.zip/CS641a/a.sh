#!/bin/bash
inputfilename="input$1.txt"
outputfilename="output$2_$3.txt"
#script typescript.txt

>$outputfilename #emptying the ciphertexts file

ssh  -T students@172.27.26.188 < $inputfilename| tr '\r' '\n' | grep -A 1 "Slowly, a new text starts appearing on the screen. It reads ..." | grep -v "Slowly, a new text starts appearing on the screen. It reads ..." | grep -v "^-" | sed -e 's/^[ \t]*//' >> $outputfilename

#exit