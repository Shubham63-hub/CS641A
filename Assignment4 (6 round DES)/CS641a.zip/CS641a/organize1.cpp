#include <bits/stdc++.h>
#include "func.h"
using namespace std;


int main(){
    ofstream out1,out2;
    ifstream in11,in12,in21,in22;
    in11.open("output1_1.txt", ios::in);
    in12.open("output1_2.txt", ios::in);
    in21.open("output2_1.txt", ios::in);
    in22.open("output2_2.txt", ios::in);
    out1.open("outputs_c1.txt");
    out2.open("outputs_c2.txt");
    
    //cout<<xor_input<<endl;
    while(!in11.eof()){
        string str11,str12,str21,str22;
        in11 >> str11,in12>>str12,in21>>str21,in22>>str22;
        if(str11.length()!=16)continue;
        // cout<<str21<<" "<<str22<<"\n";
        //cout<<str<<"\n";
        // char ip1[64];
        str11=stringToBin(str11);
        str12=stringToBin(str12);
        str21=stringToBin(str21);
        str22=stringToBin(str22);
        str11=reverseFP(str11);
        str12=reverseFP(str12);
        str21=reverseFP(str21);
        str22=reverseFP(str22);
        out1<<BinToHex(str11)<<","<<BinToHex(str12)<<"\n";
        out2<<BinToHex(str21)<<","<<BinToHex(str22)<<"\n";
        
    }
}

