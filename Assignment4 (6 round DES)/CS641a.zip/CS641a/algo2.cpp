// Now we have the XOR of output of 4th round to be 0054 0000 0400 0000 with probability (1/4)*(5/128)*(1)*(5/128)
#include <bits/stdc++.h>
#include<unistd.h>
#include "func.h"
using namespace std;


int main()
{
    ofstream out;
    ifstream in1;
    ifstream in2;
    in1.open("out_put2.txt", ios::in);
    out.open("Key6_part2.txt");
    int A[9][65]={};
    int x=0;
    int X[5]={1,2,4,5,6};
    while(!in1.eof())
    {
        x++;
        string s1,s2,tmp;
        in1>>s1>>tmp>>s2;
        s1=stringToBin(s1);
        s2=stringToBin(s2);
        string T1=reverseFP(s1);
        string T2=reverseFP(s2);
        string r6_1=T1.substr(32,32);
        string r6_2=T2.substr(32,32);
        string l6_1=T1.substr(0,32);
        string l6_2=T2.substr(0,32);
        string r2_x="00000000000000000000010000000000";
        string r6_x=string_xor(r6_1,r6_2);
        string l6_x=string_xor(l6_1,l6_2);
        string r5_1=l6_1;
        string r5_2=l6_2;
        string exp1=expansionof(r5_1);
        string exp2=expansionof(r5_2);
       // cout<<exp1<<" "<<exp2<<"\n";
        string Fx=string_xor(r6_x,r2_x);
        string s6_out=inverse_perm(Fx);
        for(auto k:X)
        {
            string exp1k=exp1.substr(6*(k-1),6);
            string exp2k=exp2.substr(6*(k-1),6);
            string s6k=s6_out.substr(4*(k-1),4);
            findKey(exp1k,exp2k,k-1,A[k],s6k);
        }
        // if(x==250)break;
    }
    int ans,tmp=-1;
    int key[6];
    for(int i:X)
    {
        vector<pair<int,int> > k1;
        out<<i<<"->";
        tmp=-1;
        for(int j=0;j<65;j++)
        {
            k1.push_back({A[i][j],j});
            if(A[i][j]>tmp)
            {
                ans=j;
                tmp=A[i][j];
            }
        }
        sort(k1.begin(),k1.end(),greater<pair<int,int> >());
        for(auto i:k1)
        {
            
            out<<"("<<i.second<<" "<<i.first<<") ";
        }
        out<<"\n";
    }

    return 0;
}