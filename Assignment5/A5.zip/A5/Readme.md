Dependencies needs to be installed before running:
    sshpass
    To install sshpass in ubuntu:
        sudo apt install sshpass

To run the code (execution will take about 30 seconds):
    make (Top level directory)

To re-run:
    first clean by running "make clean" in top level directory 
    make 