#!/bin/bash
inputfilename="./inputs/input$1a.txt"
outputfilename="./outputs/output$1.txt"
#script typescript.txt

>$outputfilename #emptying the ciphertexts file

sshpass -p "cs641a" ssh  -T students@172.27.26.188 < $inputfilename| tr '\r' '\n' | grep -A 1 "Slowly, a new text starts appearing on the screen. It reads ..." | grep -v "Slowly, a new text starts appearing on the screen. It reads ..." | grep -v "^-" | sed -e 's/^[ \t]*//' >> $outputfilename

#exit