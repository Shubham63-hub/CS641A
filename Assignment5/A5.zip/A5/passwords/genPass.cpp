#include<bits/stdc++.h>
using namespace std;
int main()
{
    // ifstream inp;
    // inp.open("actpass");
    ofstream ina1,inb1;
    ina1.open("./passwords/password.txt");
    ina1<<"The_Triple_Hits\ncrypto123\n5\ngo\nwave\ndive\ngo\nread\n";
    string inp="password";
    ina1<<inp<<"\n"<<"c\n";
    ina1<<"back\nexit";
}



// p=0
// f1=open("input1a.txt","w")
// f2=open("input1b.txt","w")
// f1.write("The_Triple_Hits\ncrypto123\n5\ngo\nwave\ndive\ngo\nread\n")
// A=['f','g','h','i','j','k','l','m']
// B=['f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u']
// inp=['f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f','f']

// for a1 in A:
//     for b1 in B:
//         o1=""
//         inp[0]=a1
//         inp[1]=b1
//         out1=""
//         for j in (range(0,16)):
//             out1+=inp[j]
//         f1.write(out1)
//         f1.write("\n")
//         f1.write('c\n')
//         f2.write(out1)
//         f2.write("\n")
// f1.write("back\nexit")