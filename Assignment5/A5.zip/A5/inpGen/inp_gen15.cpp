#include<bits/stdc++.h>
using namespace std;
int main()
{
    ifstream inp1;
    inp1.open("./prefixes/prefix14.txt");
    string prefix;
    inp1>>prefix;
    ofstream ina1,inb1;
    ina1.open("./inputs/input15a.txt");
    inb1.open("./inputs/input15b.txt");
    string A="fghijklm",B="fghijklmnopqrstu";
    ina1<<"The_Triple_Hits\ncrypto123\n5\ngo\nwave\ndive\ngo\nread\n";
    int x=28;
    string inp="ffffffffffffffffffffffffffffffff";
    int i=0;
    // cout<<prefix<<"\n";
    for(auto x:prefix)
    {
        inp[i++]=x;
    }
    for(auto a:A)
    {
        for(auto b:B)
        {
            inp[x]=a;
            inp[x+1]=b;
            ina1<<inp<<"\n"<<"c\n";
            inb1<<inp<<"\n";
        }
    }
    ina1<<"back\nexit";
}
