#include<bits/stdc++.h>
using namespace std;
int main()
{
    ifstream inp1;
    inp1.open("./passwords/passCT.txt");
    string pass_cipherText;
    inp1>>pass_cipherText;
    ifstream inp2;
    inp2.open("./outputs/output14.txt");
    ifstream inp3;
    inp3.open("./inputs/input14b.txt");
    ofstream pref;
    pref.open("./prefixes/prefix14.txt");
    string cipherText;
    string plainText;
    while(!inp2.eof())
    {
        inp2>>cipherText;
        inp3>>plainText;
        if(cipherText.substr(0,28)==pass_cipherText.substr(0,28))
        {
            pref<<plainText.substr(0,28)<<"\n";
        }
    }

}


