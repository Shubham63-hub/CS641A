#include<bits/stdc++.h>
using namespace std;
int main()
{
    ifstream inp1;
    inp1.open("./passwords/passCT.txt");
    string pass_cipherText;
    inp1>>pass_cipherText;
    ifstream inp2;
    inp2.open("./outputs/output6.txt");
    ifstream inp3;
    inp3.open("./inputs/input6b.txt");
    ofstream pref;
    pref.open("./prefixes/prefix6.txt");
    string cipherText;
    string plainText;
    while(!inp2.eof())
    {
        inp2>>cipherText;
        inp3>>plainText;
        if(cipherText.substr(0,12)==pass_cipherText.substr(0,12))
        {
            pref<<plainText.substr(0,12)<<"\n";
        }
    }

}

