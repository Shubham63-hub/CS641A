#include<bits/stdc++.h>
using namespace std;

int main()
{
    ifstream inp;
    inp.open("./prefixes/prefix16.txt");
    ofstream out;
    out.open("Ans");
    string s;
    while(!inp.eof())
    {
        char c1,c2;
        inp>>c1;
        inp>>c2;
        s+=(char)((c1-'f')*16+(c2-'f'));
    }
    while(s.back()=='0')
    {
        s.pop_back();
    }
    out<<s<<"\n";
    cout<< "Password is: "<< s <<endl;
}