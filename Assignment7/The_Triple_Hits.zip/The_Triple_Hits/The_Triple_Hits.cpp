#include <iostream>
#include <vector>
using namespace std;
int p[] = {21, 17, 72, 108, 110, 21, 117, 121, 49, 74, 88, 44, 122, 109, 116, 117, 119, 2, 17, 19, 114, 41, 24, 33, 70, 116, 28, 100, 80, 4, 44, 13};

int mod = 127;
int power(int k, int i, int p = 127)
{
    int res = 1;
    k = k % p;

    if (k == 0)
        return 0;

    while (i > 0)
    {
        if (i & 1)
            res = (res * k) % p;
        i = i >> 1;
        k = (k * k) % p;
    }
    return res;
}

int POW(int a, int b)
{
    int res = 1;
    while (b)
    {
        res = res * a;
        b--;
    }
    return res;
}
int main()
{

    vector<char> roots;

    int total_roots = 0;
    while (total_roots < 21)
    {
        int k = 2;
        int e[22];
        e[0] = 1;
        e[1] = p[1];
        // 22 Newton Identities
        while (k < 22-total_roots )
        {
            int i = 1;
            bool b = 1;
            e[k] = 0;
            while (i <= k)
            {
                e[k] = (e[k] + (POW(-1, i - 1) * (e[k - i] * p[i]) % mod) % mod + mod) % mod;
                i++;
            }
            e[k] = (e[k] * power(k, mod - 2)) % mod;
            k++;
        }
        k = 1;
        int i = 20;
        for (int i = 1; i < 127; i++)
        {
            int x = 0;
            // sum(j=0 to 21)((-1)^j*e[j]*(x^{21-j}))  ( for x=i ) 
            for (int j = 0; j < 22-total_roots; j++)
            {
                x = (x + (POW(-1, j) * (e[j] * power(i, 21 -total_roots- j)) % mod) % mod + mod) % mod;
            }
            if (x % mod == 0)
            {
                roots.push_back(i);
                // removing root i from the hash values
                for (int j = 0; j < 32; j++)
                {
                    p[j] = (p[j] - power(i, j) + mod) % mod;
                }
                total_roots++;
                break;
            }
        }
    }
    string pass;
    for (auto i : roots)
        pass.push_back(i);
    cout << "Pass: " << pass << "\n";
}
